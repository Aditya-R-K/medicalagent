"""HTTP interface."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import BackgroundTasks, FastAPI, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from . import config, db, ingest, store
from .pipeline import Pipeline
from .providers import available_models

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("aidoctor")

settings = config.load()


@asynccontextmanager
async def lifespan(_: FastAPI):
    log.info("starting with %s", settings.describe())
    for issue in settings.problems():
        log.warning("configuration: %s", issue)
    db.connect(settings)
    ingest.scan(settings)
    yield
    db.close()


app = FastAPI(title="AI Doctor", version="2.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatTitle(BaseModel):
    title: str = Field(min_length=1, max_length=200)


class Question(BaseModel):
    content: str = Field(min_length=1, max_length=8000)


# --------------------------------------------------------------------------- #
# system
# --------------------------------------------------------------------------- #


@app.get("/api/health")
def health() -> dict:
    try:
        db.query_one("SELECT 1 AS ok")
    except Exception as exc:
        raise HTTPException(503, f"database unavailable: {exc}") from exc
    return {"status": "ok"}


@app.get("/api/settings")
def read_settings() -> dict:
    indexed = db.query_one(
        "SELECT count(*) AS documents, coalesce(sum(chunk_count), 0) AS passages "
        "FROM documents WHERE status = 'indexed'"
    )
    return {
        **settings.describe(),
        "documents_indexed": indexed["documents"],
        "passages_indexed": indexed["passages"],
        "indexing": ingest.is_running(),
        "problems": settings.problems(),
    }


@app.get("/api/models")
def read_models(kind: str = "chat") -> dict:
    return {"models": available_models(settings, kind)}


# --------------------------------------------------------------------------- #
# documents
# --------------------------------------------------------------------------- #


@app.get("/api/documents")
def list_documents() -> dict:
    documents = db.query("SELECT * FROM documents ORDER BY filename")
    return {"documents": documents, "indexing": ingest.is_running()}


@app.post("/api/documents")
async def upload_documents(files: list[UploadFile]) -> dict:
    root = settings.document_root
    root.mkdir(parents=True, exist_ok=True)
    saved = []

    for upload in files:
        name = Path(upload.filename or "").name
        if not name:
            continue
        if Path(name).suffix.lower() not in ingest.SUPPORTED:
            raise HTTPException(400, f"{name}: only PDF, TXT and MD files are supported")
        target = root / name
        with target.open("wb") as handle:
            shutil.copyfileobj(upload.file, handle)
        saved.append(name)

    ingest.scan(settings)
    return {"saved": saved}


@app.post("/api/documents/{document_id}/exclude")
def exclude_document(document_id: int) -> dict:
    """Drop a document from the index and stop reindexing it.

    The file itself is never touched. This application has no business deleting
    documents out of a folder on someone's machine, and a mounted folder gives
    no recycle bin to recover from.
    """
    record = db.query_one("SELECT * FROM documents WHERE id = %s", (document_id,))
    if not record:
        raise HTTPException(404, "no such document")
    # The passages are kept. Search already filters on status, so excluding is
    # a flag rather than a deletion, and including again costs nothing instead
    # of paying to embed the whole document a second time.
    db.execute("UPDATE documents SET status = 'excluded' WHERE id = %s", (document_id,))
    return {"excluded": record["filename"]}


@app.post("/api/documents/{document_id}/include")
def include_document(document_id: int) -> dict:
    record = db.query_one("SELECT * FROM documents WHERE id = %s", (document_id,))
    if not record:
        raise HTTPException(404, "no such document")
    db.execute(
        """
        UPDATE documents
        SET status = CASE WHEN chunk_count > 0 THEN 'indexed' ELSE 'pending' END
        WHERE id = %s AND status = 'excluded'
        """,
        (document_id,),
    )
    return {"included": record["filename"]}


@app.post("/api/documents/index")
def start_indexing(tasks: BackgroundTasks, rebuild: bool = False) -> dict:
    issues = settings.problems()
    if issues:
        raise HTTPException(400, issues[0])
    if ingest.is_running():
        return {"started": False, "reason": "indexing is already running"}
    tasks.add_task(ingest.index_pending, settings, rebuild)
    return {"started": True}


# --------------------------------------------------------------------------- #
# chats
# --------------------------------------------------------------------------- #


@app.get("/api/chats")
def list_chats() -> dict:
    return {"chats": store.list_chats()}


@app.post("/api/chats")
def create_chat() -> dict:
    return store.create_chat()


@app.patch("/api/chats/{chat_id}")
def rename_chat(chat_id: int, body: ChatTitle) -> dict:
    if not store.get_chat(chat_id):
        raise HTTPException(404, "no such chat")
    store.rename_chat(chat_id, body.title)
    return {"id": chat_id, "title": body.title}


@app.delete("/api/chats/{chat_id}")
def delete_chat(chat_id: int) -> dict:
    if not store.get_chat(chat_id):
        raise HTTPException(404, "no such chat")
    store.delete_chat(chat_id)
    return {"deleted": chat_id}


@app.get("/api/chats/{chat_id}/messages")
def list_messages(chat_id: int) -> dict:
    if not store.get_chat(chat_id):
        raise HTTPException(404, "no such chat")
    return {"messages": store.list_messages(chat_id)}


@app.post("/api/chats/{chat_id}/messages")
async def send_message(chat_id: int, body: Question) -> StreamingResponse:
    chat = store.get_chat(chat_id)
    if not chat:
        raise HTTPException(404, "no such chat")

    issues = settings.problems()
    if issues:
        raise HTTPException(400, issues[0])

    question = body.content.strip()
    history = store.history_for_model(chat_id)
    store.add_message(chat_id, "user", question)
    if chat["title"] == "New chat":
        store.rename_chat(chat_id, store.derive_title(question))

    async def events():
        queue: asyncio.Queue = asyncio.Queue()
        loop = asyncio.get_running_loop()

        def produce() -> None:
            # The pipeline is synchronous; run it off the event loop so streaming
            # to the browser is not blocked by provider calls.
            try:
                for event in Pipeline(settings).answer(question, history):
                    loop.call_soon_threadsafe(queue.put_nowait, event)
            except Exception as exc:
                log.exception("pipeline failed")
                loop.call_soon_threadsafe(
                    queue.put_nowait, {"type": "error", "text": str(exc)}
                )
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        await loop.run_in_executor(None, lambda: None)
        task = loop.run_in_executor(None, produce)
        citations: list = []

        while True:
            event = await queue.get()
            if event is None:
                break
            if event["type"] == "citations":
                citations = event["citations"]
            if event["type"] == "complete":
                result = event["result"]
                saved = store.add_message(chat_id, "assistant", result.answer, citations)
                yield _sse({"type": "done", "message_id": saved["id"]})
                continue
            yield _sse(event)

        await task

    return StreamingResponse(
        events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event, default=str)}\n\n"
