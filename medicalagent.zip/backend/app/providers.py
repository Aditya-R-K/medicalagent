"""Chat and embedding providers: OpenAI and Ollama."""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Iterator, Sequence

log = logging.getLogger(__name__)

OPENAI_DEFAULT_BASE_URL = "https://api.openai.com/v1"

try:
    import tiktoken

    _ENCODING = tiktoken.get_encoding("cl100k_base")
except Exception:  # pragma: no cover
    _ENCODING = None


class ProviderError(RuntimeError):
    pass


def count_tokens(text: str) -> int:
    if _ENCODING is not None:
        return max(1, len(_ENCODING.encode(text)))
    return max(1, int(len(text.split()) * 1.3))


def truncate(text: str, limit: int) -> str:
    if _ENCODING is None:
        words = text.split()
        budget = int(limit / 1.3)
        return text if len(words) <= budget else " ".join(words[:budget])
    tokens = _ENCODING.encode(text)
    return text if len(tokens) <= limit else _ENCODING.decode(tokens[:limit])


def parse_json(text: str) -> dict | None:
    """Pull a JSON object out of a reply that may be wrapped in prose or fences."""
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    fence = re.search(r"```(?:json)?\s*(.+?)```", text, flags=re.S)
    if fence:
        text = fence.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        parsed = json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def _retryable(exc: Exception) -> bool:
    text = f"{type(exc).__name__} {exc}".lower()
    return any(
        marker in text
        for marker in ("ratelimit", "rate limit", "timeout", "connection", "502", "503", "529")
    )


def _with_retries(operation, attempts: int, label: str):
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return operation()
        except Exception as exc:
            last = exc
            if not _retryable(exc) or attempt == attempts - 1:
                break
            time.sleep(2**attempt)
    raise ProviderError(f"{label}: {last}")


def _openai_client(settings):
    from openai import OpenAI

    if not settings.openai_api_key:
        raise ProviderError("OPENAI_API_KEY is not set")
    # Passed explicitly rather than left to the client's environment lookup,
    # which accepts an empty OPENAI_BASE_URL as a real override.
    return OpenAI(
        api_key=settings.openai_api_key,
        base_url=(settings.openai_base_url or "").strip() or OPENAI_DEFAULT_BASE_URL,
    )


def _ollama_client(settings):
    import ollama

    return ollama.Client(host=settings.ollama_host)


# --------------------------------------------------------------------------- #
# chat
# --------------------------------------------------------------------------- #


class ChatModel:
    def __init__(self, settings) -> None:
        self.settings = settings
        self.provider = settings.llm_provider
        self.model = settings.chat_model
        self.name = f"{self.provider}:{self.model}"
        self._client = (
            _openai_client(settings) if self.provider == "openai" else _ollama_client(settings)
        )

    def _messages(self, system: str, user: str, history: list[dict] | None) -> list[dict]:
        messages = [{"role": "system", "content": system}]
        messages.extend(history or [])
        messages.append({"role": "user", "content": user})
        return messages

    def _ollama_options(self) -> dict:
        # Ollama defaults to a small context window and silently drops the
        # start of anything longer. The specialist prompts carry several
        # thousand tokens of passages, so the window is set explicitly.
        return {"temperature": 0, "num_ctx": self.settings.ollama_num_ctx}

    def complete(self, system: str, user: str, history: list[dict] | None = None,
                 json_only: bool = False) -> str:
        messages = self._messages(system, user, history)

        def call() -> str:
            if self.provider == "openai":
                arguments = {"model": self.model, "messages": messages, "temperature": 0}
                if json_only:
                    arguments["response_format"] = {"type": "json_object"}
                response = self._client.chat.completions.create(**arguments)
                return response.choices[0].message.content or ""
            response = self._client.chat(
                model=self.model, messages=messages, options=self._ollama_options(),
                format="json" if json_only else "",
            )
            return response["message"]["content"]

        return _with_retries(call, 4, f"{self.name} request failed").strip()

    def stream(
        self, system: str, user: str, history: list[dict] | None = None
    ) -> Iterator[str]:
        """Yield the reply in pieces, so the interface can render as it arrives."""
        messages = self._messages(system, user, history)
        try:
            if self.provider == "openai":
                stream = self._client.chat.completions.create(
                    model=self.model, messages=messages, temperature=0, stream=True
                )
                for part in stream:
                    if part.choices and part.choices[0].delta.content:
                        yield part.choices[0].delta.content
            else:
                for part in self._client.chat(
                    model=self.model, messages=messages,
                    options=self._ollama_options(), stream=True,
                ):
                    piece = part.get("message", {}).get("content")
                    if piece:
                        yield piece
        except Exception as exc:
            raise ProviderError(f"{self.name} stream failed: {exc}") from exc

    def structured(self, system: str, user: str, fallback: dict) -> tuple[dict, bool]:
        """Ask for JSON, falling back rather than failing when it cannot be parsed."""
        reply = self.complete(
            f"{system}\n\nReply with a single JSON object and nothing else.", user,
            json_only=True,
        )
        parsed = parse_json(reply)
        if parsed is None:
            log.info("%s returned unparseable JSON; using fallback", self.name)
            return dict(fallback), False
        return parsed, True


# --------------------------------------------------------------------------- #
# embeddings
# --------------------------------------------------------------------------- #


class EmbeddingModel:
    """Fixed to OpenAI's text-embedding-3-large.

    Every passage and every question must pass through the same model for the
    comparison to mean anything, and changing it invalidates the whole index, so
    this is deliberately not configurable.
    """

    def __init__(self, settings) -> None:
        self.settings = settings
        self.provider = settings.embed_provider
        self.model = settings.embed_model
        self.dim = settings.embed_dim
        self.name = f"{self.provider}:{self.model}"
        self.batch_size = 128
        self.max_tokens = 8000
        self._client = _openai_client(settings)

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        vectors: list[list[float]] = []
        for start in range(0, len(texts), self.batch_size):
            batch = [truncate(t, self.max_tokens) for t in texts[start : start + self.batch_size]]
            vectors.extend(self._encode(batch))
        return vectors

    def embed_one(self, text: str) -> list[float]:
        return self._encode([truncate(text, self.max_tokens)])[0]

    def _encode(self, batch: list[str]) -> list[list[float]]:
        def call() -> list[list[float]]:
            arguments = {"model": self.model, "input": batch}
            if self.settings.truncating:
                # Shortening the vector keeps it inside pgvector's index limit
                # and still beats a smaller model at the same width.
                arguments["dimensions"] = self.dim
            response = self._client.embeddings.create(**arguments)
            return [item.embedding for item in response.data]

        vectors = _with_retries(call, 4, f"{self.name} embedding failed")
        if vectors and len(vectors[0]) != self.dim:
            raise ProviderError(
                f"{self.name} returned {len(vectors[0])} dimensions but EMBED_DIM "
                f"is {self.dim}."
            )
        return vectors


def available_models(settings, kind: str) -> list[str]:
    """What the configured provider reports. Empty when it cannot be reached."""
    try:
        if settings.llm_provider == "ollama":
            client = _ollama_client(settings)
            names = [
                entry.get("model") or entry.get("name")
                for entry in client.list().get("models", [])
            ]
            if names:
                return sorted(n for n in names if n)
        if settings.openai_api_key:
            client = _openai_client(settings)
            ids = sorted(model.id for model in client.models.list().data)
            embeddings = [i for i in ids if "embedding" in i]
            return embeddings if kind == "embedding" else [i for i in ids if i not in embeddings]
    except Exception as exc:
        log.info("could not list models: %s", exc)
    return []
